from setuptools import setup, find_packages

setup( 
    name="tercerRepo",
    version="0.1.0",
    packages= find_packages(),
    author="Santiago Valdés",
    author_email="mauriciovaldesf@hotmai.com",
    url="https://github.com/Chago2",
    description="Tercer repositorio de prueba para el curso de GitHub",
    )